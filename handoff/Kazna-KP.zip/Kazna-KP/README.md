# Казна

Платформа для финансового директора и управляющих сети:  
остатки, кассы, заявки, платёжный календарь, связка с iiko.

## Клиенту

| Файл | Что это |
|---|---|
| [kp.html](kp.html) | Коммерческое предложение (варианты A / B) |
| [preview/](preview/) | Эскизы экранов платформы |

## Внутри (не клиенту)

| Файл | Что это |
|---|---|
| [docs/roadmap-internal.html](docs/roadmap-internal.html) | Рынок, цена, внутренний роадмап |

## Как открыть КП

- Локально: скачать репозиторий → открыть `kp.html` в браузере  
- Или включить GitHub Pages (Settings → Pages → Deploy from `main` / root) и слать ссылку вида  
  `https://mrsergeyesmirnov-svg.github.io/kazna/kp.html`

ИП Смирнов Сергей Евгеньевич · [@yank0vski](https://t.me/yank0vski) · [pulseteam.online](https://pulseteam.online/)
